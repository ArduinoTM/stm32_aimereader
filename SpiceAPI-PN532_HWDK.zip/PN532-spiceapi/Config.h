//#ifndef CONFIG_h
//#define CONFIG_h
//
//
//
///* Launch game with "-api 1337 -apipass changeme -apiserial COM1 -apiserialbaud 57600" or similar */
///* Adjust your serial port here(Serial, Serial1, Serial2, etc.) - WiFi/Network support is possible, but out of scope for this project */
//#define SPICEAPI_INTERFACE Serial
//#define SPICEAPI_BAUD 115200 
//#define SPICEAPI_PASS ""
///* For games with multiple readers */
//#define SPICEAPI_PLAYERNUM 0
//
///* ISO14443 support (for older Aime/Nesica/BANAPASSPORT cards... reader will pretend it was a FeliCa for maximum cardio compatibility) */
//#define WITH_ISO14443 1
////auto enable 14443
//#endif
